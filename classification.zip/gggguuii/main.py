import mimetypes
import os
from UI.main_ui2 import Ui_MainWindow
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMainWindow
import sys
from pathlib import Path
import time
from ultralytics import YOLO
import pathlib
import threading
import cv2
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtCore import Qt

mimetypes.init()
width = 0
height = 0
temp = pathlib.PosixPath
pathlib.PosixPath = pathlib.WindowsPath


class Do_detection1(threading.Thread):
    def __init__(self):
        super().__init__()
        self.stop_event = threading.Event()

    def run_(self, image, model):
        res = model(image,conf=0.2)
        res_plotted = res[0].plot()
        boxes = []
        label = []
        for result in res:
            boxes = result.boxes.xywh  # Boxes object for bounding box outputs
            label = result.boxes.cls

        return boxes, res_plotted, label


class DoClassification(threading.Thread):
    def __init__(self, model):
        super().__init__()
        self.model = model
        self.stop_event = threading.Event()

    def run_(self, image, box):
        print(box)
        x_center, y_center, w, h = int(box[0]), int(box[1]), int(box[2]), int(box[3])
        x = x_center - w // 2
        y = y_center - h // 2
        im = image[y:y + h, x:x + w]
        res = self.model(im,conf=0.7)
        label = 0
        for result in res:
            probs = result.probs
            label = probs.top1

        return label


class main_window(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super(main_window, self).__init__(parent)
        self.setupUi(self)
        self.stop_value = 0
        self.setWindowTitle("hieroglyphic ")
        self.source = 0

        self.model_yolv8_orginal = YOLO("models/detection.pt")
        self.model_yolv8_c = YOLO("models/direction.pt")

        self.first()

    def first(self):
        self.open_2.setStyleSheet("background-color: green")
        self.exit_2.setStyleSheet("background-color: red")
        font = QtGui.QFont()
        font.setPointSize(10)
        self.exit_2.pressed.connect(self.exit_fn)
        self.open_2.pressed.connect(self.open_fn)

    def run_(self, f):
        if self.check_file(f):
            self.image_name = f
            self.image = cv2.imread(f)
            self.basename_without_ext = os.path.splitext(os.path.basename(f))[0]
            self.original = self.image.copy()
            Path("Results").mkdir(parents=True, exist_ok=True)
            thread_detection1 = Do_detection1()
            thread_detection1.start()
            thread_classification = DoClassification(self.model_yolv8_c)
            thread_classification.start()

            boxes, res_plotted, labels = thread_detection1.run_(self.image, self.model_yolv8_orginal)
            classficion_labels=[5,6,7,8,12,16,18,19,23,24,27,28,29,30,31,32,33,36,38,39,40,42,45,46,47,48,50,52,54,55]

            dir=[]
            for box,label in zip(boxes,labels):
                if label in classficion_labels:
                  id = thread_classification.run_(self.image, box )
                  dir.append(id)
            # 0 left 1 right
            direction = "right" if dir.count(1) > dir.count(0) else "left"
            self.dir.setText(direction)

            self.update_out_image(res_plotted)
            cv2.imwrite("Results/"+self.basename_without_ext+".jpg",res_plotted)
            if cv2.waitKey(40) == 27:
                pass

            cv2.destroyAllWindows()

    def update_out_image(self, cv_img):
        cv_img_rgb = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)

        height, width, channel = cv_img_rgb.shape
        bytes_per_line = 3 * width
        q_image = QImage(cv_img_rgb.data, width, height, bytes_per_line, QImage.Format_RGB888)

        pixmap = QPixmap.fromImage(q_image)
        pixmap = pixmap.scaled(self.out_put_image_2.width(), self.out_put_image_2.height(), Qt.KeepAspectRatio)

        scene = QtWidgets.QGraphicsScene()
        scene.addPixmap(pixmap)

        self.out_put_image_2.setScene(scene)

    def exit_fn(self):
        # sys.exit(0)
        os._exit(1)

        self.run_()

    def check_file(self, fileName):
        mimestart = mimetypes.guess_type(fileName)[0]
        if mimestart != None:
            mimestart = mimestart.split('/')[0]
            if mimestart in ['video', 'image']:
                return True
        return False

    def open_fn(self):
        file_types = {
            'Image': ('*.jpg *.png *.jpeg', 'Image Files'),
        }
        file_type = file_types['Image']
        if file_type:
            self.source, _ = QtWidgets.QFileDialog.getOpenFileName(
                None, f"Open {os.getcwd()} Data File", '.', f"{file_type[1]} ({file_type[0]})"
            )
        if self.source:
            time.sleep(1 / 40)
            self.run_(self.source)


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QStackedWidget()
    main = main_window()

    splash_pix = QtGui.QPixmap('row/main.jpg')
    splash = QtWidgets.QSplashScreen(splash_pix, QtCore.Qt.WindowStaysOnTopHint)
    opaqueness = 0.0
    step = 0.1
    splash.setWindowOpacity(opaqueness)
    splash.show()
    while opaqueness < 1:
        splash.setWindowOpacity(opaqueness)
        time.sleep(step)  # Gradually appears
        opaqueness += step

    # set Windows full screen
    screenGeometry = QtWidgets.QApplication.instance().desktop().screenGeometry()
    availGeometry = QtWidgets.QApplication.instance().desktop().availableGeometry()
    width, height = availGeometry.width(), availGeometry.height()
    main.setFixedSize(width - 15, height - 30)
    # self.out_put_image_2.setGeometry(x, y, width, height)
    main.out_put_image_2.setGeometry(QtCore.QRect(80, 20, width - 100, height - 60))
    main.show()
    splash.close()
    sys.exit(app.exec_())
